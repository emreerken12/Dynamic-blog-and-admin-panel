<?php

// Bağlantı bilgileri
$servername = "localhost";
$username = "root"; // Kendi kullanıcı adınızı buraya yazın
$password = ""; // Kendi şifrenizi buraya yazın
$dbname = "artvias_yeni";

// Bağlantı oluşturma
$conn = new mysqli($servername, $username, $password, $dbname);

// Bağlantı kontrolü
if ($conn->connect_error) {
    die("Bağlantı başarısız: " . $conn->connect_error);
} else {

}




?>