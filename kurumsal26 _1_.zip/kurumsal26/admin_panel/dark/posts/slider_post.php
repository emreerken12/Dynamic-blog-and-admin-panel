<?php
include '../database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $slider1text = $_POST['slider1_text'] ?? '';
    $slider2text = $_POST['slider2_text'] ?? '';
    $slider3text = $_POST['slider3_text'] ?? '';

    $upload_dir = 'uploads/';

    $slider1img = $_FILES['slider1_img']['name'] ?? null;
    $slider2img = $_FILES['slider2_img']['name'] ?? null;
    $slider3img = $_FILES['slider3_img']['name'] ?? null;

    $slider1img_path = $slider1img ? $upload_dir . basename($slider1img) : null;
    $slider2img_path = $slider2img ? $upload_dir . basename($slider2img) : null;
    $slider3img_path = $slider3img ? $upload_dir . basename($slider3img) : null;

    if ($slider1img_path && !move_uploaded_file($_FILES['slider1_img']['tmp_name'], $slider1img_path)) {
        $slider1img_path = 'Upload failed for slider 1 image';
    }
    if ($slider2img_path && !move_uploaded_file($_FILES['slider2_img']['tmp_name'], $slider2img_path)) {
        $slider2img_path = 'Upload failed for slider 2 image';
    }
    if ($slider3img_path && !move_uploaded_file($_FILES['slider3_img']['tmp_name'], $slider3img_path)) {
        $slider3img_path = 'Upload failed for slider 3 image';
    }

    $sql = "UPDATE slider_info2 SET title = ?, image_url = ? WHERE id = 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $slider1text, $slider1img);
    $stmt->execute();

    $sql = "UPDATE slider_info2 SET title = ?, image_url = ? WHERE id = 2";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $slider2text, $slider2img);
    $stmt->execute();

    $sql = "UPDATE slider_info2 SET title = ?, image_url = ? WHERE id = 3";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $slider3text, $slider3img);
    $stmt->execute();

header("location:../index.php");


    $stmt->close();
    $conn->close();
    
}
?>
