<?php
include '../database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $project_name = $_POST['project_name1'] ?? '';
    $project_description = $_POST['project_description'] ?? '';
    $project_category_name = $_POST['project_category_name'] ?? '';

    $upload_dir = 'uploads/';

    $project_image_url = $_FILES['project_image_url']['name'] ?? null;

    // Set the path for the uploaded image
    $project_image_url_path = $project_image_url ? $upload_dir . basename($project_image_url) : null;

    // Move the uploaded file to the desired directory
    if ($project_image_url_path && !move_uploaded_file($_FILES['project_image_url']['tmp_name'], $project_image_url_path)) {
        $project_image_url_path = 'Upload failed for project_image_url';
    }

    $sql = "UPDATE projects SET project_name = ?, project_description = ?, project_category_name = ?, project_image_url = ? WHERE id = 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $project_name, $project_description, $project_category_name, $project_image_url);
    $stmt->execute();

    header("Location: ../index.php");

    $stmt->close();
    $conn->close();
}
?>
